CSS：
@charset "UTF-8";
.back1 img{
	position: absolute;
	height:722px;
	width:498px;
	left:0; 
	right:0; 
	top:0; 
	bottom:0;
    margin:auto;
	background-repeat: no-repeat;
	z-index: 1;
}
.back2 img{
   position: absolute;
   width:53px;
   height:56px;
   left:565px;
   top:335px;
   z-index: 1;
}
.back3 img{
 position: absolute;
 width: 58px;
 height:50px;
 left:680px;
 top:344px;
 z-index: 1;
}
.back4 img{
 position: absolute;
 width: 52.5px;
 height: 50px;
 left:803px;
 top:340px;
 z-index: 1;
}
.back5 img{
 position: absolute;
 width: 73px;
 height: 51px;
 left:916px;
 top:343px;
 z-index: 1;
}
.link1{
	position: absolute;
	border-right: solid #FF6347 2.4px;
	width:0px;
	height:384.2px;
	left: 530px;   /*530px*/
	top:325.5px;
}
.link2{
	position: absolute;
	border-top:solid #FF6347 2.4px; 
	height: 0px;
	width:119px;
	left:530px;
	top:325px;
}
.link3{
	position: absolute;
	border-right: solid #FF6347 2.4px;
	width:0px;
	height: 125px;
    left:646px;
    top:325px;
}
.link4{
	position: absolute;
	border-top: solid #FF6347 2.4px;
	width:359px;
	height: 0px;
	left:646px;
	top:450.5px;
}
.link5{
	position: absolute;
	border-right:solid #FF6347 2.4px;
	width:0px;
	height: 258px;
	left:1004px;
	top:450.5px;
}
.link6{
	position: absolute;
	border-top: solid #FF6347 2.4px;
	width:476px;
	height: 0px;
	left:530px;
	top:707px;
}
.link7{
	position: absolute;
	border-top: solid #FF6347 4px;
	width:54px;
	height: 0px;
	left:738px;
	top:202px;
}
p.font1{ /*高宽度比1.22*/
	position: absolute;
	font-size:18pt;
	color:#FF6347;
	left:601px;
	top:1.45px;
	z-index: 1;
}
p.font2{
	position: absolute;
	font-size: 18pt;
	color:#FF6347;
	left:709.5px;
	top:1.45px;
	z-index: 1;
}
p.font3{
	position: absolute;
	font-size: 18pt;
	color:#FF6347;
	left:817.5px;
	top:1.45px;
	z-index: 1;
}
p.font4{
	position: absolute;
	font-size: 18pt;
	color:#FF6347;
	left:925.5px;
	top:1.45px;
	z-index: 1;
}

p.wenzi1{
	position: absolute;
	word-spacing: 10px;
	font-size:14pt;
	left:580px;
	top:35.5px;
	z-index: 1;
}
p.wenzi2{
	position: absolute;
	word-spacing: 10px;
	font-size: 14pt;
	top:35.5px;
	left:688px;
	z-index: 1;
}
p.wenzi3{
	position: absolute;
	word-spacing: 10px;
	font-size: 14pt;
	top:35.5px;
	left:796.5px;
	z-index: 1;
}
p.wenzi4{
	position: absolute;
	word-spacing: 10px;
	font-size: 14pt;
	top:35.5px;
	left:904.5px;
	z-index: 1;
}
p.wenzi5{
	position: absolute;
	word-spacing: 15px;
	font-size: 14.6pt;
	top:91.5px;
	left:665px;
	color:#FF6347;
	z-index:2;
}
p.wenzi6{
	position: absolute;
	font-size: 14.6pt;
	left:567px;
	top:153px;
	z-index: 1;
}
p.wenzi7{
	position: absolute;
	font-size: 14.6pt;
	left:656px;
	top:153px;
	z-index: 1;
}
p.wenzi8{
	position: absolute;
	font-size: 14.6pt;
	left:745px;
	top:153px;
	z-index: 1;
}
p.wenzi9{
	position: absolute;
	font-size: 14.6pt;
	left:833px;
	top:153px;
	z-index: 1;
}
p.wenzi10{
	position: absolute;
	font-size: 14.6pt;
	left:922px;
	top:153px;
	z-index: 1;
}
p.wenzi11{
	position: absolute;
	font-size: 14.6pt;
	left:548.1px;
	top:212px;
	color:#FF6347;
	z-index: 1;
}
p.wenzi12{
	position: absolute;
	font-size: 14.6pt;
	left:764px;
	top:212px;
	color:#FF6347;
	z-index: 1;
}
p.wenzi13{
	position: absolute;
	font-size: 14.6pt;
	left:549px;
	top:251.2px;
	z-index: 1;
}
p.wenzi14{
	position: absolute;
	font-size: 14.6pt;
	left:763.5px;
	top:250.9px;
	z-index: 1;
}
p.wenzi15{
	position: absolute;
	font-size: 14.6pt;
	left:560px;
	top:379px;
	color:#FF6347;
	z-index: 1;
}
p.wenzi16{
	position: absolute;
	font-size: 14.6pt;
	left:688px;
	top:379.5px;
	z-index: 1;
}
p.wenzi17{
	position: absolute;
	font-size: 14.6pt;
	left:807px;
	top:379px;
	z-index: 1;
}
p.wenzi18{
	position: absolute;
	font-size: 14.6pt;
	left:927px;
	top:379.5px;
	z-index: 1;
}
p.wenzi19{
	position: absolute;
	font-size: 14.6pt;
	left:572.5px;
	top:447px;
	color:#FF6347;
	z-index: 1;
}
p.wenzi20{
	position: absolute;
	font-size: 14.6pt;
	left:670.5px;
	top:446.5px;
	z-index: 1;
}
p.wenzi21{
	position: absolute;
	font-size: 14.6pt;
	left:768px;
	top:447px;
	z-index: 1;
}
p.wenzi22{
	position: absolute;
	font-size: 14.6pt;
	left:866px;
	top:447px;
	z-index: 1;
}
p.wenzi23{
	position: absolute;
	font-size: 14.6pt;
	left:566px;
	top:496px;
	z-index: 1;
}
p.wenzi24{
	position: absolute;
	font-size: 14.6pt;
	left:565px;
	top:539px;
	z-index: 1;
}
p.wenzi25{
	position: absolute;
	font-size: 14.6pt;
	left:563px;
	top:582px;
	z-index: 1;
}
p.wenzi26{
	position: absolute;
	font-size: 14.6pt;
	left:606px;
	top:582px;
	z-index: 1;
}
p.wenzi27{
	position: absolute;
	font-size: 14.6pt;
	left:630.5px;
	top:583px;
	color:#FF6347;
	z-index: 1;
}
p.wenzi28{
	position: absolute;
	font-size: 14.6pt;
	color: white;
	left:573px;
	top:627px;
	z-index: 1;
}
p.wenzi29{
	position: absolute;
	font-size:21pt;
	color:silver;
	opacity:1;
	left:976px;
	top: 422px;
}
#rectangle1{
	position: absolute;
	top:105px;
	left:533px;
	width:470px;
	height:40px;
	background:#FAEBD7 ;
	z-index: 1;
}
#rectangle2{
	position: absolute;
	top:0px;
	left:520px;
	width:498px;
	height:722px;
	background:silver ;
	z-index:0.1;
	opacity: .2;
}
#rectangle3{
	position: absolute;
	top:10px;
	left:533px;
	width:470px;
	height:700px;
	background:white ;
	z-index:0.2;
}
#rectangle4{
	position: absolute;
	width:308px;
	height:40.4px;
	left:557px;
	top:507px;
	border:solid 2px silver;
	z-index:3;
	opacity:1;
}
#rectangle5{
	position: absolute;
	width:307.5px;
	height:40.4px;
	left:557px;
	top:548px;
	border:solid 2px silver;
	z-index:3;
	opacity:1;
}
#rectangle6{
	position: absolute;
	width:111px;
	height: 45px;
	left:557px;
	top:638px;
	background-color: #FF6347;
    border-radius: 4px;
}
.d1{
	position: absolute;
	left: 909px;
	top:115px;
	width:0;
	height:0;
	border-width: 10px;
    border-style: solid;
    border-color: transparent transparent transparent red;
    z-index: 2;
}

HTML：
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>实验四</title>
<link rel="stylesheet" type="text/css" href="CSS1.css">
</head>
<body>
    <div class="back2"><img src="../photo/p1.png"></div>
    <div class="back3"><img src="../photo/p2.png"></div>
    <div class="back4"><img src="../photo/p3.png"></div>
    <div class="back5"><img src="../photo/p4.png"></div>
    <p class="font1">5</p>
    <p class="font2">0</p>
    <p class="font3">0</p>
    <p class="font4">1</p>
    <p class="wenzi1">待收货</p>
    <p class="wenzi2">待发货</p>
    <p class="wenzi3">待付款</p>
    <p class="wenzi4">待评价</p>
    <p class="wenzi5">网上有害信息举报专区</p>
    <p class="wenzi6">公告</p>
    <p class="wenzi7">规则</p>
    <p class="wenzi8">论坛</p>
    <p class="wenzi9">安全</p>
    <p class="wenzi10">公益</p>
    <p class="wenzi11">淘宝1212大促招商</p>
    <p class="wenzi12">在线职业培训招商</p>
    <p class="wenzi13">金秋超值购招商</p>
    <p class="wenzi14">运营神器年中大促</p>
    <p class="wenzi15">充话费</p>
    <p class="wenzi16">旅行</p>
    <p class="wenzi17">车险</p>
    <p class="wenzi18">游戏</p>
    <p class="wenzi19">充话费</p>
    <p class="wenzi20">充流量</p>
    <p class="wenzi21">充固话</p>
    <p class="wenzi22">充宽带</p>
    <p class="wenzi23">请输入手机号码</p>
    <p class="wenzi24">50元</p>
    <p class="wenzi25">售价</p>
    <p class="wenzi26">￥</p>
    <p class="wenzi27">49 -49 .8</p>
    <p class="wenzi28">立即充值</p>
    <p class="wenzi29">×</p>
    <div id="rectangle1"></div>
    <div id="rectangle2"></div>
    <div id="rectangle3"></div>
    <div id="rectangle4"></div>
    <div id="rectangle5"></div>
    <div id="rectangle6"></div>
    <div class="d1"></div>
    <div class="link1"></div>
    <div class="link2"></div>
    <div class="link3"></div>
    <div class="link4"></div>
    <div class="link5"></div>
    <div class="link6"></div>
    <div class="link7"></div>
</body>
</html>
